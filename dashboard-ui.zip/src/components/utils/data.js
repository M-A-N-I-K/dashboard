export const Data = [
    {
        id: 0,
        users: 20,
        contribution: 20,
    },
    {
        id: 1,
        users: 25,
        contribution: 20,
    },


    {
        id: 2,
        users: 30,
        contribution: 30,
    },


    {
        id: 3,
        users: 35,
        contribution: 45,
    },
    {
        id: 4,
        users: 40,
        contribution: 60,
    },
    {
        id: 5,
        users: 45,
        contribution: 70,
    },
    {
        id: 6,
        users: 50,
        contribution: 85,
    }, {
        id: 7,
        users: 55,
        contribution: 100,
    }
    , {
        id: 8,
        users: 60,
        contribution: 120,
    }, {
        id: 9,
        users: 65,
        contribution: 150,
    }
];